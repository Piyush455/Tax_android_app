package com.example.taxcalculator.taxcalculator;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText enteredAmount;
    private SeekBar seekBar;
    private Button calculateButton;
    private TextView resultTextView;
    private TextView textSeek;
    private int SeekbarPercentage;
    private double enteredDouble;
    private TextView textViewTotals;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enteredAmount=(EditText) findViewById(R.id.editText);
        seekBar=(SeekBar) findViewById(R.id.seekBar);
        calculateButton=(Button) findViewById(R.id.button2);
        resultTextView=(TextView) findViewById(R.id.textView4);
        textSeek=(TextView) findViewById(R.id.textViewseekBar);
        textViewTotals=(TextView) findViewById(R.id.textViewTotal);

        calculateButton.setOnClickListener(this);
        textSeek.setText("0%");

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textSeek.setText(String.valueOf(seekBar.getProgress()) + "%");

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                SeekbarPercentage=seekBar.getProgress();

            }
        });
    }

    @Override
    public void onClick(View v){

        calculate();

    }

    public void calculate(){
        double resultTax=0.0d;
        double resultBill=0.0d;
        if(!enteredAmount.getText().toString().equals("")) {
            enteredDouble = Double.parseDouble(enteredAmount.getText().toString());
            resultTax = (SeekbarPercentage * enteredDouble) / 100;
            resultTextView.setText("Your Tax amount is: Rs " + String.format("%.2f",resultTax));
            resultBill=enteredDouble+resultTax;
            textViewTotals.setText("Total bill: Rs " + String.format("%.2f",resultBill));


        }
        else{
            Toast.makeText(MainActivity.this,"Please enter a bill amount.",Toast.LENGTH_LONG).show();
        }

    }

}

